    $(document).ready(function () {
        $('.eliminar_confirm').on('click',function () {
            var boton=$(this);
            bootbox.confirm('¿Está seguro de eliminar este registro?', function (result) {
                if (result) {
                    window.location=boton.data('url');
                }
            });
        })

    });


